Catarina Pinheiro Correia - up201405765
Jos� Aleixo Cruz - up201403526

Credenciais para uma das contas do site:

username: cat
password: 123456

-N�o h� administradores no site.

-As bibliotecas externas utilizadas est�o na pasta vendors, sendo que o php-mailer (que permite enviar mails usando PHP) n�o chegou a ser implementado. O simple-php-captcha gera um captcha para controlar o processo de login.

-O ficheiro 'script.sql' � respons�vel por popular a base de dados (ficheiro chamado db), que se encontra em database/sqlite.