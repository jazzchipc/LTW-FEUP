
<?php
  include('../templates/header.php'); 
?>

<h1>Best restaurants</h1>

<?php

  include('../templates/restaurant_show_best.php');

  include('../templates/footer.php');
?>