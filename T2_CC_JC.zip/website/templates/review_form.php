<div id="title">
    <label>Title
    <input type="text" name="title" required>
    </label>
</div>

<div id="score">
    <label>Score
    <label><input type="radio" name="score" value="1" required>1</label>
    <label><input type="radio" name="score" value="2" required>2</label>
    <label><input type="radio" name="score" value="3" required>3</label>
    <label><input type="radio" name="score" value="4" required>4</label>
    <label><input type="radio" name="score" value="5" required>5</label>
    </label>
</div>

<div id="review">
    <label>Review
    <textarea name="review" required></textarea>
    </label>
</div>
<div>
    <input type="submit" value="Submit">
</div>

