  <footer>
    
    <h1>Developed for LTW-FEUP</h1> 
    <p>by Catarina Correia and José Aleixo</p>

  </footer>
  
  </content>

  <right-margin></right-margin>

  </flex-box>

  
  </body>
</html>
