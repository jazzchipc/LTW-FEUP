<?php
    foreach($reviews as $review){
        include ('../templates/review_show.php');
    }
?>