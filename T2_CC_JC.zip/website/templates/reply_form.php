<div id="reply_comment">
    <label>Review
    <textarea name="reply_comment" required></textarea>
    </label>
</div>
<div>
    <input type="submit" value="Submit">
</div>

