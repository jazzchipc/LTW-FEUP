<?php
    foreach($users as $user){
        include ('../templates/user_info_short.php');
    }
?>